from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models import Team
from .utils import admin_required

manage_team_bp = Blueprint('manage_team', __name__)

@manage_team_bp.route('/team/manage')

def list_teams():
    teams = Team.query.all()
    return render_template('manage_teams.html', teams=teams)

@manage_team_bp.route('/team/manage/create', methods=['POST'])

def create_team():
    db.session.add(Team(
        name=request.form['name'],
        description=request.form.get('description')
    ))
    db.session.commit()
    flash('Team erstellt')
    return redirect(url_for('manage_team.list_teams'))

@manage_team_bp.route('/team/manage/<int:id>/delete', methods=['POST'])

def delete_team(id):
    Team.query.filter_by(id=id).delete()
    db.session.commit()
    flash('Team gelöscht')
    return redirect(url_for('manage_team.list_teams'))

@manage_team_bp.route('/team/manage/<int:id>/edit', methods=['GET','POST'])

def edit_team(id):
    team = Team.query.get_or_404(id)
    if request.method == 'POST':
        team.name = request.form['name']
        team.description = request.form.get('description')
        db.session.commit()
        flash('Team aktualisiert')
        return redirect(url_for('manage_team.list_teams'))
    return render_template('edit_team.html', team=team)