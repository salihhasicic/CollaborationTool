from functools import wraps
from flask import abort
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import User

def admin_required(fn):
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        user = User.query.get(get_jwt_identity())
        if not user or user.role != 'admin':
            abort(403)
        return fn(*args, **kwargs)
    return wrapper